# AllJourney

WWDC23 Swift Student Challenge project.

## About the project
The project is a game which the user helps a little witch to rescue her father, who was kidnapped by a dark witch. For that, the player must complet some logical math challenges, so the main character, Sophia, learns a new spell. With this new knowledge, it's possible to advance in the game, until the final level, in which sophia rescues her father.
The purpose of the game is to make that the user develops a logical math thinking and has fun in the process by using the speels and scrolling the map.
It's necessary to say that the game was develop just for Iphones, in reason to be more portable than others Apple products, and the interface was made for the Iphone 14.


## About the creative process
At the beginning of this year (2023), I went through some difficult moments with my mental health. One of the things that most made me forget my problems and make me fell good was watching and playing something related to Harry Potter's saga. And being a big fan, I had the idea to make a game that entered on this magical world. 
Besides that, I'm an engineering student and I like math a lot, and one thing that helped me to develop a mathematical logical thinking, in addition to agility in math problems, was practice on apps that involves this type of challenge.
So, I`ve joined both of this ideas and develop the "Rescue", which I hope that the users can have fun and learn a little bit while playing.


## Credits
Sound:
- music1: "Full of Energy (Non-Commercial)" (https://freesound.org/s/520192/) by code_box is licensed under Creative Commons Attribution-NonCommercial ( http://creativecommons.org/licenses/by-nc/4.0/ )


#
Finally, I want to thank my mentors, my family and friends, that helped me and supported through all this challenge.


This project is author by me, Luis Paulo Siqueira.
